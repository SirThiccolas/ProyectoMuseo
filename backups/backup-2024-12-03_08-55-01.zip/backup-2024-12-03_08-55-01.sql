-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: fenosa
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bens_exposats`
--

DROP TABLE IF EXISTS `bens_exposats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bens_exposats` (
  `id_exposicio` int(11) NOT NULL,
  `id_obra` varchar(255) NOT NULL,
  KEY `fk_id_expo` (`id_exposicio`),
  KEY `fk_id_obra` (`id_obra`),
  CONSTRAINT `fk_id_expo` FOREIGN KEY (`id_exposicio`) REFERENCES `exposicions` (`ID_Expo`),
  CONSTRAINT `fk_id_obra` FOREIGN KEY (`id_obra`) REFERENCES `bens_patrimonials` (`Num_Registro`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bens_exposats`
--

LOCK TABLES `bens_exposats` WRITE;
/*!40000 ALTER TABLE `bens_exposats` DISABLE KEYS */;
INSERT INTO `bens_exposats` VALUES (1,'B001'),(1,'B003'),(2,'B001'),(2,'B002'),(3,'B002'),(3,'B004'),(4,'B002'),(4,'B003'),(5,'B001'),(5,'B004'),(6,'B003'),(6,'B004'),(7,'B001'),(7,'B002'),(8,'B002'),(8,'B003');
/*!40000 ALTER TABLE `bens_exposats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bens_patrimonials`
--

DROP TABLE IF EXISTS `bens_patrimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bens_patrimonials` (
  `Num_Registro` varchar(255) NOT NULL,
  `Fotografia` varchar(255) DEFAULT NULL,
  `Classificacio_Generica` int(11) DEFAULT NULL,
  `Nom_Objecte` varchar(255) DEFAULT NULL,
  `Colleccio_Procedencia` varchar(255) DEFAULT NULL,
  `Mides_Maxima_Alcada_cm` decimal(10,2) DEFAULT NULL,
  `Mides_Maxima_Amplada_cm` decimal(10,2) DEFAULT NULL,
  `Mides_Maxima_Profunditat_cm` decimal(10,2) DEFAULT NULL,
  `Material` int(11) DEFAULT NULL,
  `Tecnica` int(11) DEFAULT NULL,
  `Autor` int(11) DEFAULT NULL,
  `Titol` varchar(255) DEFAULT NULL,
  `Any_Inicial` int(11) DEFAULT NULL,
  `Any_Final` int(11) DEFAULT NULL,
  `Datacio` int(11) DEFAULT NULL,
  `Data_Registro` date DEFAULT NULL,
  `Forma_Ingres` int(11) DEFAULT NULL,
  `Data_Ingres` date DEFAULT NULL,
  `Font_Ingres` varchar(255) DEFAULT NULL,
  `Baixa` varchar(3) DEFAULT NULL,
  `Causa_Baixa` int(11) DEFAULT NULL,
  `Data_Baixa` date DEFAULT NULL,
  `Persona_Autoritz_Baixa` int(11) DEFAULT NULL,
  `Estat_Conservacio` int(11) DEFAULT NULL,
  `Lloc_Execucio` varchar(255) DEFAULT NULL,
  `Lloc_Procedencia` varchar(255) DEFAULT NULL,
  `Num_Tiratge` int(11) DEFAULT NULL,
  `Altres_Numeros_Identificacio` varchar(255) DEFAULT NULL,
  `Valoracio_Economica_Euros` decimal(10,2) DEFAULT NULL,
  `Bibliografia` text DEFAULT NULL,
  `Descripcio` text DEFAULT NULL,
  `Historia_Objecte` text DEFAULT NULL,
  `ID_Ubicacio` int(11) DEFAULT NULL,
  `ID_Expo` int(11) DEFAULT NULL,
  `usuario_registra` int(11) DEFAULT NULL,
  PRIMARY KEY (`Num_Registro`),
  KEY `ID_Ubicacio` (`ID_Ubicacio`),
  KEY `ID_Expo` (`ID_Expo`),
  KEY `usuario_registra` (`usuario_registra`),
  KEY `fk_vocabulario_autor` (`Autor`),
  KEY `fk_vocabulario_causa_baixa` (`Causa_Baixa`),
  KEY `fk_vocabulario_classificacio_generica` (`Classificacio_Generica`),
  KEY `fk_vocabulario_datacio` (`Datacio`),
  KEY `fk_vocabulario_estat_conservacio` (`Estat_Conservacio`),
  KEY `fk_vocabulario_forma_ingres` (`Forma_Ingres`),
  KEY `fk_vocabulario_material` (`Material`),
  KEY `fk_vocabulario_tecnica` (`Tecnica`),
  KEY `fk_usuari_autoritzat_baixa` (`Persona_Autoritz_Baixa`),
  CONSTRAINT `fk_usuari_autoritzat_baixa` FOREIGN KEY (`Persona_Autoritz_Baixa`) REFERENCES `usuaris` (`ID_Usuari`),
  CONSTRAINT `fk_usuario_registra` FOREIGN KEY (`usuario_registra`) REFERENCES `usuaris` (`ID_Usuari`),
  CONSTRAINT `fk_vocabulario_autor` FOREIGN KEY (`Autor`) REFERENCES `vocabulario_autores` (`id`),
  CONSTRAINT `fk_vocabulario_causa_baixa` FOREIGN KEY (`Causa_Baixa`) REFERENCES `vocabulario_causas_baja` (`id`),
  CONSTRAINT `fk_vocabulario_classificacio_generica` FOREIGN KEY (`Classificacio_Generica`) REFERENCES `vocabulario_classificacio_generica` (`id`),
  CONSTRAINT `fk_vocabulario_datacio` FOREIGN KEY (`Datacio`) REFERENCES `vocabulario_datacions` (`id`),
  CONSTRAINT `fk_vocabulario_estat_conservacio` FOREIGN KEY (`Estat_Conservacio`) REFERENCES `vocabulario_estados_conservacion` (`id`),
  CONSTRAINT `fk_vocabulario_forma_ingres` FOREIGN KEY (`Forma_Ingres`) REFERENCES `vocabulario_formas_ingreso` (`id`),
  CONSTRAINT `fk_vocabulario_material` FOREIGN KEY (`Material`) REFERENCES `vocabulario_material` (`id`),
  CONSTRAINT `fk_vocabulario_tecnica` FOREIGN KEY (`Tecnica`) REFERENCES `vocabulario_tecnica` (`id`),
  CONSTRAINT `fk_vocabulario_tipos_exposicion` FOREIGN KEY (`ID_Expo`) REFERENCES `exposicions` (`ID_Expo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bens_patrimonials`
--

LOCK TABLES `bens_patrimonials` WRITE;
/*!40000 ALTER TABLE `bens_patrimonials` DISABLE KEYS */;
INSERT INTO `bens_patrimonials` VALUES ('B001','B001.jpg',1,'Vasija de cerámica maya','Colección Arqueológica',25.00,15.00,10.00,2,1,3,'Vasija ceremonial',1200,0,6,'2024-10-01',2,'2020-05-20','Donación de particular','No',NULL,NULL,NULL,4,'Chichén Itzá','Chichén Itzá',0,'B001-2020',1500.00,'Referencias en el catálogo arqueológico maya.','Vasija utilizada en ceremonias de ofrendas.','Esta pieza fue descubierta durante excavaciones en Chichén Itzá.',4,1,1),('B002','B002.jpg',NULL,'Estatua romana de mármol','Colección Romana',180.00,60.00,50.00,3,2,4,'Escultura de patricio',150,NULL,7,'2024-10-02',3,'2019-04-15','Adquisición en subasta','No',2,'0000-00-00',1,5,'Roma','Roma',NULL,'B002-2019',50000.00,'Mencionada en textos de historia del arte romano.','Estatua de mármol representando a un patricio romano.','Descubierta en una villa romana cerca de Pompeya.',3,1,2),('B003','B003.jpg',3,'Máscara funeraria egipcia','Colección Egipcia',45.00,30.00,20.00,1,2,5,'Máscara funeraria',-200,12312313,2,'2024-10-03',3,'2021-06-10','Donación por parte de una fundación','No',NULL,NULL,NULL,4,'Giza','Gizaa',323,'B003-2021',100000.00,'Documentada en varias investigaciones sobre el periodo predinástico.','Máscara funeraria perteneciente a un dignatario egipcio.','Encontrada en una tumba real durante excavaciones en Giza.',2,2,3),('B004','B004.jpg',4,'Espada vikinga','Colección de Armas',90.00,15.00,5.00,2,4,6,'Espada ceremonial',900,950,6,'2024-10-04',5,'2018-07-30','Compra directa','No',NULL,NULL,NULL,5,'Escandinavia','Oslo',NULL,'B004-2018',20000.00,'Citada en varios estudios sobre armamento vikingo.','Espada utilizada en ceremonias rituales.','Esta espada fue encontrada en un barco vikingo durante excavaciones en Oslo.',1,4,1),('B005','B005.jpg',2,'Anillo romano','Colección Romana',2.00,1.00,0.50,4,1,5,'Anillo de oro',-100,0,3,'2024-10-05',1,'2022-11-05','Herencia familiar','No',NULL,NULL,NULL,4,'Roma','Roma',NULL,'B005-2022',750.00,'Estudios arqueológicos de joyería romana.','Anillo perteneciente a un patricio romano.','Recuperado durante la excavación de una villa romana.',1,3,2),('B006','B006.jpg',3,'Cuchillo ceremonial azteca','Colección Arqueológica',30.00,5.00,1.50,3,4,7,'Cuchillo de obsidiana',1400,1521,5,'2024-10-06',2,'2020-08-14','Compra en galería','No',NULL,NULL,NULL,5,'Tenochtitlán','Tenochtitlán',NULL,'B006-2020',3000.00,'Incluido en estudios sobre la cultura azteca.','Utilizado en ceremonias de sacrificio.','Hallado en Tenochtitlán durante excavaciones.',2,2,3),('B007','B007.jpg',1,'Vasija griega de cerámica','Colección Clásica',35.00,20.00,20.00,2,1,3,'Ánfora decorada',-500,-400,7,'2024-10-07',3,'2021-10-10','Donación privada','No',NULL,NULL,NULL,3,'Atenas','Atenas',NULL,'B007-2021',4500.00,'Estudios en arte griego clásico.','Ánfora utilizada en banquetes ceremoniales.','Hallada en una tumba en Atenas.',1,1,4),('B008','B008.jpg',4,'Escultura de un león','Colección Escultura Medieval',100.00,30.00,50.00,1,2,6,'León en mármol',1300,1350,2,'2024-10-08',4,'2018-05-19','Adquisición en subasta','No',NULL,NULL,NULL,5,'París','París',NULL,'B008-2018',12000.00,'Referencias en estudios de arte medieval.','Escultura de un león guardián.','Parte de una serie de esculturas en catedrales.',1,4,1),('B009','B009.jpg',3,'Máscara tribal africana','Colección Etnográfica',25.00,15.00,5.00,2,4,8,'Máscara de madera',1800,0,6,'2024-10-09',3,'2020-10-25','Compra directa','No',NULL,NULL,NULL,4,'Nigeria','Nigeria',NULL,'B009-2020',800.00,'Estudios de arte africano.','Máscara utilizada en ceremonias.','Adquirida en Nigeria.',2,1,2),('B010','B010.jpg',1,'Jarro egipcio','Colección Egipcia',35.00,20.00,15.00,3,2,9,'Jarro decorativo',-1500,-1400,5,'2024-10-10',5,'2021-09-11','Donación de particular','No',NULL,NULL,NULL,5,'Luxor','Luxor',NULL,'B010-2021',6500.00,'Incluido en estudios de alfarería egipcia.','Jarro para almacenamiento de alimentos.','Descubierto en Luxor.',1,2,4),('B011','B011.jpg',2,'Escudo medieval','Colección de Armas',80.00,60.00,5.00,1,3,5,'Escudo de caballero',1200,1300,2,'2024-10-11',1,'2019-02-17','Compra privada','No',NULL,NULL,NULL,3,'Londres','Londres',NULL,'B011-2019',7500.00,'Estudios en armamento medieval.','Escudo de un caballero inglés.','Hallado en una fortaleza en Inglaterra.',2,3,1),('B012','B012.jpg',4,'Arco japonés','Colección Oriental',150.00,10.00,5.00,3,4,7,'Arco ceremonial',1700,1800,6,'2024-10-12',2,'2022-02-21','Compra en subasta','No',NULL,NULL,NULL,4,'Kyoto','Kyoto',NULL,'B012-2022',1100.00,'Referencias en cultura samurái.','Arco utilizado en ceremonias samurái.','Recuperado en un templo de Kyoto.',2,4,3),('B013','B013.jpg',2,'Collar de jade','Colección Precolombina',5.00,3.00,0.20,4,2,8,'Collar ceremonial',-500,-400,7,'2024-10-13',3,'2019-10-01','Donación de fundación','No',NULL,NULL,NULL,5,'Perú','Perú',NULL,'B013-2019',12000.00,'Estudios en cultura precolombina.','Collar ceremonial de jade.','Adquirido en una fundación arqueológica en Perú.',1,3,2),('B014','B014.jpg',1,'Amuleto de bronce','Colección Clásica',2.00,1.00,0.50,3,1,6,'Amuleto protector',-200,-100,3,'2024-10-14',5,'2021-07-30','Herencia privada','No',NULL,NULL,NULL,3,'Esparta','Esparta',NULL,'B014-2021',600.00,'Documentado en estudios de arte clásico.','Amuleto con poderes protectores.','Hallado en una tumba en Esparta.',1,2,4),('B015','B015.jpg',4,'Copa romana','Colección Romana',10.00,8.00,8.00,2,3,9,'Copa de vidrio',100,200,7,'2024-10-15',4,'2018-09-15','Adquisición en galería','No',NULL,NULL,NULL,4,'Roma','Roma',NULL,'B015-2018',3200.00,'Estudios sobre arte romano.','Copa utilizada en banquetes romanos.','Adquirida en una galería de arte en Roma.',1,1,3);
/*!40000 ALTER TABLE `bens_patrimonials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exposicions`
--

DROP TABLE IF EXISTS `exposicions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exposicions` (
  `ID_Expo` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Expo` varchar(255) DEFAULT NULL,
  `Data_Inici_Expo` date DEFAULT NULL,
  `Data_Fi_Expo` date DEFAULT NULL,
  `Tipus_Expo` int(11) DEFAULT NULL,
  `Lloc_Exposicio` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID_Expo`),
  KEY `Tipus_Expo` (`Tipus_Expo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exposicions`
--

LOCK TABLES `exposicions` WRITE;
/*!40000 ALTER TABLE `exposicions` DISABLE KEYS */;
INSERT INTO `exposicions` VALUES (1,'Exposición de Arte Moderno','2024-01-01','2024-03-31',1,'Museu Nacional d\'Art de Catalunya'),(2,'Historia del Arte','2024-04-01','2024-06-30',1,'Museu d\'Història de Catalunya'),(3,'Maestros del Renacimiento','2024-07-01','2024-09-30',2,'Museu Picasso'),(4,'El Impresionismo','2024-10-01','2024-12-31',2,'Museu del Disseny de Barcelona'),(5,'Arte Contemporáneo','2024-01-15','2024-04-15',2,'Centre de Cultura Contemporània de Barcelona'),(6,'La Escultura a Través de los Siglos','2024-05-01','2024-07-31',1,'Museu de les Arts Decoratives'),(7,'Pinturas de la Naturaleza','2024-08-01','2024-10-31',2,'Museu d\'Art de Girona'),(8,'Arte Urbano','2024-11-01','2025-01-31',1,'Museu d\'Art Contemporani de Barcelona');
/*!40000 ALTER TABLE `exposicions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `moviments`
--

DROP TABLE IF EXISTS `moviments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `moviments` (
  `ID_Moviment` int(11) NOT NULL AUTO_INCREMENT,
  `Museu_Procedencia` varchar(255) DEFAULT NULL,
  `Data_Inici` date DEFAULT NULL,
  `Data_Fi` date DEFAULT NULL,
  `Obra_moguda` varchar(255) DEFAULT NULL,
  `Museu_Actual` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID_Moviment`),
  KEY `fk_obra_moguda` (`Obra_moguda`),
  CONSTRAINT `fk_obra_moguda` FOREIGN KEY (`Obra_moguda`) REFERENCES `bens_patrimonials` (`Num_Registro`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `moviments`
--

LOCK TABLES `moviments` WRITE;
/*!40000 ALTER TABLE `moviments` DISABLE KEYS */;
INSERT INTO `moviments` VALUES (1,'Museo de Arte Moderno','2023-03-01','2023-05-01','B002','Museu Apel·les Fenosa'),(2,'Museu Apel·les Fenosa','2023-06-01','2023-09-01','B003','Museo Nacional');
/*!40000 ALTER TABLE `moviments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restauracions`
--

DROP TABLE IF EXISTS `restauracions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `restauracions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_inici` date DEFAULT NULL,
  `data_fi` date DEFAULT NULL,
  `comentari` text DEFAULT NULL,
  `nom_restaurador` text DEFAULT NULL,
  `id_obra` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restauracions`
--

LOCK TABLES `restauracions` WRITE;
/*!40000 ALTER TABLE `restauracions` DISABLE KEYS */;
INSERT INTO `restauracions` VALUES (1,'2022-01-15','2022-02-10','Restauración completa de la superficie dañada.','Joan Pérez','B001'),(2,'2022-03-05','2022-03-20','Limpieza y conservación preventiva.','Marta González','B002'),(3,'2022-06-10','2022-07-15','Reparación de grietas y pulido.','Carlos López','B003'),(4,'2023-01-25','2023-02-05','Sustitución de piezas faltantes.','Ana Fernández','B004'),(5,'2023-03-12','2023-03-30','Restauración de color original.','Luis Sánchez','B001'),(6,'2023-04-05','2023-04-18','Conservación de los detalles dorados.','María Díaz','B002'),(7,'2023-05-20','2023-06-10','Reparación de daños estructurales.','José García','B003'),(8,'2023-08-01','2023-08-15','Limpieza profunda de la superficie.','Clara Morales','B004'),(9,'2023-09-10','2023-09-25','Aplicación de capa protectora.','Pablo Ruiz','B001'),(10,'2023-10-12','2023-10-28','Reparación de daños por humedad.','Sofía Hernández','B002');
/*!40000 ALTER TABLE `restauracions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ubicacions`
--

DROP TABLE IF EXISTS `ubicacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ubicacions` (
  `ID_Ubicacio` int(11) NOT NULL AUTO_INCREMENT,
  `Nom` varchar(255) DEFAULT NULL,
  `padre` int(11) DEFAULT NULL,
  `descripcion` text DEFAULT NULL,
  PRIMARY KEY (`ID_Ubicacio`),
  KEY `padre` (`padre`),
  CONSTRAINT `fk_padre` FOREIGN KEY (`padre`) REFERENCES `ubicacions` (`ID_Ubicacio`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ubicacions`
--

LOCK TABLES `ubicacions` WRITE;
/*!40000 ALTER TABLE `ubicacions` DISABLE KEYS */;
INSERT INTO `ubicacions` VALUES (1,'Sala 1',NULL,'Primera planta del museo'),(2,'Sala 2',NULL,'Segunda planta del museo'),(3,'Sub-Sala 1',1,'Subdivisión de Sala 1'),(4,'Sub-Sala 2',2,'sub sala 2'),(5,'ej 1',4,'ej 1'),(6,'ej 2',4,'ej 2');
/*!40000 ALTER TABLE `ubicacions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuaris`
--

DROP TABLE IF EXISTS `usuaris`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuaris` (
  `ID_Usuari` int(11) NOT NULL AUTO_INCREMENT,
  `Nom_Usuari` varchar(255) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL,
  `Rol` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID_Usuari`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuaris`
--

LOCK TABLES `usuaris` WRITE;
/*!40000 ALTER TABLE `usuaris` DISABLE KEYS */;
INSERT INTO `usuaris` VALUES (1,'admin','admin@example.com','admin','admin'),(2,'tecnico','tecnico@example.com','tecnico','tecnico'),(3,'invitado','invitado@example.com','invitado','invitado'),(4,'admin2','admin2@gmail.com','admin','tecnico');
/*!40000 ALTER TABLE `usuaris` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_autores`
--

DROP TABLE IF EXISTS `vocabulario_autores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_autores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_autores`
--

LOCK TABLES `vocabulario_autores` WRITE;
/*!40000 ALTER TABLE `vocabulario_autores` DISABLE KEYS */;
INSERT INTO `vocabulario_autores` VALUES (9,'Andy Warhol'),(5,'Claude Monet'),(3,'Frida Kahlo'),(7,'Georgia O\'Keeffe'),(8,'Jackson Pollock'),(4,'Leonardo da Vinci'),(10,'Michelangelo'),(1,'Pablo Picasso'),(6,'Salvador Dalí'),(2,'Vincent van Gogh');
/*!40000 ALTER TABLE `vocabulario_autores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_causas_baja`
--

DROP TABLE IF EXISTS `vocabulario_causas_baja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_causas_baja` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `causa` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `causa` (`causa`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_causas_baja`
--

LOCK TABLES `vocabulario_causas_baja` WRITE;
/*!40000 ALTER TABLE `vocabulario_causas_baja` DISABLE KEYS */;
INSERT INTO `vocabulario_causas_baja` VALUES (1,'Confiscacio'),(2,'Destrucció'),(3,'Estat de conservació molt deficient'),(4,'Manteniment i restauració'),(5,'Pèrdua'),(6,'Robatori'),(7,'Successió interadministrativa'),(8,'Valor patrimonial insuficient');
/*!40000 ALTER TABLE `vocabulario_causas_baja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_classificacio_generica`
--

DROP TABLE IF EXISTS `vocabulario_classificacio_generica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_classificacio_generica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_classificacio_generica`
--

LOCK TABLES `vocabulario_classificacio_generica` WRITE;
/*!40000 ALTER TABLE `vocabulario_classificacio_generica` DISABLE KEYS */;
INSERT INTO `vocabulario_classificacio_generica` VALUES (1,'Arte Prehistórico'),(2,'Arte Antiguo'),(3,'Arte Medieval'),(4,'Arte Renacentista'),(5,'Arte Barroco'),(6,'Arte Neoclásico'),(7,'Arte Moderno'),(8,'Arte Contemporáneo'),(9,'Arqueología'),(10,'Historia Natural');
/*!40000 ALTER TABLE `vocabulario_classificacio_generica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_codis_getty`
--

DROP TABLE IF EXISTS `vocabulario_codis_getty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_codis_getty` (
  `id` int(11) NOT NULL,
  `codi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_codis_getty`
--

LOCK TABLES `vocabulario_codis_getty` WRITE;
/*!40000 ALTER TABLE `vocabulario_codis_getty` DISABLE KEYS */;
/*!40000 ALTER TABLE `vocabulario_codis_getty` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_datacions`
--

DROP TABLE IF EXISTS `vocabulario_datacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_datacions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datacio` varchar(255) DEFAULT NULL,
  `any_inici` int(11) DEFAULT NULL,
  `any_final` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=246 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_datacions`
--

LOCK TABLES `vocabulario_datacions` WRITE;
/*!40000 ALTER TABLE `vocabulario_datacions` DISABLE KEYS */;
INSERT INTO `vocabulario_datacions` VALUES (1,'segle IV ante',-400,-301),(2,'primera meitat segle IV ante',-400,-351),(3,'primer quart segle IV ante',-400,-376),(4,'segon quart segle IV ante',-375,-351),(5,'segona meitat segle IV ante',-350,-301),(6,'tercer quart segle IV ante',-350,-326),(7,'últim quart segle IV ante',-325,-301),(8,'segle III ante',-300,-201),(9,'primera meitat segle III ante',-300,-251),(10,'primer quart segle III ante',-300,-276),(11,'segon quart segle III ante',-275,-251),(12,'segona meitat segle III ante',-250,-201),(13,'tercer quart segle III ante',-250,-226),(14,'últim quart segle III ante',-225,-201),(15,'segle II ante',-200,-101),(16,'primera meitat segle II ante',-200,-151),(17,'primer quart segle II ante',-200,-176),(18,'segon quart segle II ante',-175,-151),(19,'segona meitat segle II ante',-150,-101),(20,'tercer quart segle II ante',-150,-126),(21,'últim quart segle II ante',-125,-101),(22,'segle I ante',-100,-1),(23,'primera meitat segle I ante',-100,-51),(24,'primer quart segle I ante',-100,-76),(25,'segon quart segle I ante',-75,-51),(26,'segona meitat segle I ante',-50,-1),(27,'tercer quart segle I ante',-50,-26),(28,'últim quart segle I ante',-25,-1),(29,'segle I',0,100),(30,'primera meitat segle I',0,50),(31,'primer quart segle I',0,25),(32,'segon quart segle I',25,50),(33,'segona meitat segle I',50,100),(34,'tercer quart segle I',50,75),(35,'últim quart segle I',75,100),(36,'segle II',100,200),(37,'primera meitat segle II',100,150),(38,'primer quart segle II',100,125),(39,'segon quart segle II',125,150),(40,'segona meitat segle II',150,200),(41,'tercer quart segle II',150,175),(42,'últim quart segle II',175,200),(43,'segle III',200,300),(44,'primera meitat segle III',200,250),(45,'primer quart segle III',200,225),(46,'segon quart segle III',225,250),(47,'segona meitat segle III',250,300),(48,'tercer quart segle III',250,275),(49,'últim quart segle III',275,300),(50,'segle IV',300,400),(51,'primera meitat segle IV',300,350),(52,'primer quart segle IV',300,325),(53,'segon quart segle IV',325,350),(54,'segona meitat segle IV',350,400),(55,'tercer quart segle IV',350,375),(56,'últim quart segle IV',375,400),(57,'segle V',400,500),(58,'primera meitat segle V',400,450),(59,'primer quart segle V',400,425),(60,'segon quart segle V',425,450),(61,'segona meitat segle V',450,500),(62,'tercer quart segle V',450,475),(63,'últim quart segle V',475,500),(64,'segle VI',500,600),(65,'primera meitat segle VI',500,550),(66,'primer quart segle VI',500,525),(67,'segon quart segle VI',525,550),(68,'segona meitat segle VI',550,600),(69,'tercer quart segle VI',550,575),(70,'últim quart segle VI',575,600),(71,'segle VII',600,700),(72,'primera meitat segle VII',600,650),(73,'primer quart segle VII',600,625),(74,'segon quart segle VII',625,650),(75,'segona meitat segle VII',650,700),(76,'tercer quart segle VII',650,675),(77,'últim quart segle VII',675,700),(78,'segle VIII',700,800),(79,'primera meitat segle VIII',700,750),(80,'primer quart segle VIII',700,725),(81,'segon quart segle VIII',725,750),(82,'segona meitat segle VIII',750,800),(83,'tercer quart segle VIII',750,775),(84,'últim quart segle VIII',775,800),(85,'segle IX',800,900),(86,'primera meitat segle IX',800,850),(87,'primer quart segle IX',800,825),(88,'segon quart segle IX',825,850),(89,'segona meitat segle IX',850,900),(90,'tercer quart segle IX',850,875),(91,'últim quart segle IX',875,900),(92,'segle X',900,1000),(93,'primera meitat segle X',900,950),(94,'primer quart segle X',900,925),(95,'segon quart segle X',925,950),(96,'segona meitat segle X',950,1000),(97,'tercer quart segle X',950,975),(98,'últim quart segle X',975,1000),(99,'segle XI',1000,1100),(100,'primera meitat segle XI',1000,1050),(101,'primer quart segle XI',1000,1025),(102,'segon quart segle XI',1025,1050),(103,'segona meitat segle XI',1050,1100),(104,'tercer quart segle XI',1050,1075),(105,'últim quart segle XI',1075,1100),(106,'segle XII',1100,1200),(107,'primera meitat segle XII',1100,1150),(108,'primer quart segle XII',1100,1125),(109,'segon quart segle XII',1125,1150),(110,'segona meitat segle XII',1150,1200),(111,'tercer quart segle XII',1150,1175),(112,'últim quart segle XII',1175,1200),(113,'segle XIII',1201,1300),(114,'primera meitat segle XIII',1201,1250),(115,'primer quart segle XIII',1201,1225),(116,'segon quart segle XIII',1226,1250),(117,'segona meitat segle XIII',1251,1300),(118,'tercer quart segle XIII',1251,1275),(119,'últim quart segle XIII',1276,1300),(120,'segle XIV',1301,1400),(121,'primera meitat segle XIV',1301,1350),(122,'primer quart segle XIV',1301,1325),(123,'segon quart segle XIV',1326,1350),(124,'segona meitat segle XIV',1351,1400),(125,'tercer quart segle XIV',1351,1375),(126,'últim quart segle XIV',1376,1400),(127,'segle XV',1401,1500),(128,'primera meitat segle XV',1401,1450),(129,'primer quart segle XV',1401,1425),(130,'segon quart segle XV',1426,1450),(131,'segona meitat segle XV',1451,1500),(132,'tercer quart segle XV',1451,1475),(133,'últim quart segle XV',1476,1500),(134,'segle XVI',1501,1600),(135,'primera meitat segle XVI',1501,1550),(136,'primer quart segle XVI',1501,1525),(137,'segon quart segle XVI',1526,1550),(138,'segona meitat segle XVI',1551,1600),(139,'tercer quart segle XVI',1551,1575),(140,'últim quart segle XVI',1576,1600),(141,'segle XVII',1601,1700),(142,'primera meitat segle XVII',1601,1650),(143,'primer quart segle XVII',1601,1625),(144,'segon quart segle XVII',1626,1650),(145,'segona meitat segle XVII',1651,1700),(146,'tercer quart segle XVII',1651,1675),(147,'últim quart segle XVII',1676,1700),(148,'segle XVIII',1701,1800),(149,'primera meitat segle XVIII',1701,1750),(150,'primer quart segle XVIII',1701,1725),(151,'segon quart segle XVIII',1726,1750),(152,'segona meitat segle XVIII',1751,1800),(153,'tercer quart segle XVIII',1751,1775),(154,'últim quart segle XVIII',1776,1800),(155,'segle XIX',1801,1900),(156,'primera meitat segle XIX',1801,1850),(157,'primer quart segle XIX',1801,1825),(158,'dècada de 1800',1801,1810),(159,'dècada de 1810',1811,1820),(160,'dècada de 1820',1821,1830),(161,'segon quart segle XIX',1826,1850),(162,'dècada de 1830',1831,1840),(163,'dècada de 1840',1841,1850),(164,'segona meitat segle XIX',1851,1900),(165,'tercer quart segle XIX',1851,1875),(166,'dècada de 1850',1851,1860),(167,'dècada de 1860',1861,1870),(168,'dècada de 1870',1871,1880),(169,'últim quart segle XIX',1826,1850),(170,'dècada de 1880',1881,1890),(171,'dècada de 1890',1891,1900),(172,'segle XX',1901,2000),(173,'primera meitat del segle XX',1901,1950),(174,'primer quart del segle XX',1901,1925),(175,'dècada de 1900',1901,1910),(176,'dècada de 1910',1911,1920),(177,'dècada de 1920 i 1930',1921,1940),(178,'dècada de 1920',1921,1930),(179,'segon quart del segle XX',1926,1950),(180,'dècada de 1930 i 1940',1931,1950),(181,'dècada de 1930',1931,1940),(182,'dècada de 1940',1941,1950),(183,'segona meitat del segle XX',1951,2000),(184,'tercer quart del segle XX',1951,1975),(185,'dècada de 1950',1951,1960),(186,'dècada de 1960',1961,1970),(187,'dècada de 1970',1971,1980),(188,'quart quart del segle XX',1976,2000),(189,'dècada de 1980',1981,1990),(190,'dècada de 1990',1991,2000),(191,'segle XXI',2001,2100),(192,'primera meitat segle XXI',2001,2050),(193,'primer quart segle XXI',2001,2025),(194,'segon quart segle XXI',2026,2050),(195,'abans',NULL,NULL),(196,'circa',NULL,NULL),(197,'posterior',NULL,NULL),(198,'precís',NULL,NULL),(199,'Paleolític',-3000000,-9000),(200,'Paleolític Inferior',-3000000,-120000),(201,'Paleolític Inferior Arcaic',-3000000,-600000),(202,'Paleolític Inferior Peixos Evolucionades',-599999,-120000),(203,'Paleolític Inferior-Mig Indiferenciat',-119999,-50000),(204,'Paleolític Mig',-89999,-33000),(205,'Paleolític Superior',-22999,-9000),(206,'Paleolític-Epipaleolític',-10999,-7000),(207,'Epipaleolític',-8999,-5000),(208,'Neolític',-5499,-2200),(209,'Neolític Antic',-5499,-3500),(210,'Neolític Antic Cardial',-5499,-4000),(211,'Neolític Antic Postcardial',-3999,-3500),(212,'Neolític Mig-Recent',-3499,-2500),(213,'Neolític Final',-2499,-2000),(214,'Calcolític',-2199,-1800),(215,'Bronze',-1799,-650),(216,'Bronze Antic',-1799,-1500),(217,'Bronze Mig',-1499,-1200),(218,'Bronze Final',-1199,-650),(219,'Ferro-Ibèric-Colonitzacions',-649,50),(220,'Ferro-Ibèric Antic',-649,-450),(221,'Ferro-Ibèric Ple',-449,-200),(222,'Romà',-218,476),(223,'Romà República',-218,-50),(224,'Ferro-Ibèric Final',-199,-50),(225,'Romà August',-27,14),(226,'Romà Alt Imperi',14,192),(227,'Romà Segle III',192,284),(228,'Romà Baix Imperi',284,476),(229,'Medieval',400,1492),(230,'Medieval Domini Visigòtic',401,715),(231,'Medieval Ocupació i Domini Musulmà',715,799),(232,'Medieval Món Islàmic',800,1150),(233,'Medieval Catalunya Vella sota Carolingis',800,988),(234,'Medieval Món Islàmic Emirat',800,899),(235,'Medieval Món Islàmic Califat',900,1015),(236,'Medieval Comtes de Barcelona',988,1150),(237,'Medieval Món Islàmic Taifes',1016,1150),(238,'Medieval Consolidació Corona d\'Aragó',1150,1230),(239,'Medieval Baixa Edat Mitjana',1230,1492),(240,'Modern',1492,1789),(241,'Contemporani',1798,NULL),(245,'Futuro ',2050,2075);
/*!40000 ALTER TABLE `vocabulario_datacions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_estados_conservacion`
--

DROP TABLE IF EXISTS `vocabulario_estados_conservacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_estados_conservacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `estado` (`estado`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_estados_conservacion`
--

LOCK TABLES `vocabulario_estados_conservacion` WRITE;
/*!40000 ALTER TABLE `vocabulario_estados_conservacion` DISABLE KEYS */;
INSERT INTO `vocabulario_estados_conservacion` VALUES (1,'Bo'),(5,'desconeguda'),(2,'Dolent'),(3,'Excel·lent'),(4,'Indeterminat'),(6,'Regular');
/*!40000 ALTER TABLE `vocabulario_estados_conservacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_formas_ingreso`
--

DROP TABLE IF EXISTS `vocabulario_formas_ingreso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_formas_ingreso` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `forma` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `forma` (`forma`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_formas_ingreso`
--

LOCK TABLES `vocabulario_formas_ingreso` WRITE;
/*!40000 ALTER TABLE `vocabulario_formas_ingreso` DISABLE KEYS */;
INSERT INTO `vocabulario_formas_ingreso` VALUES (1,'cessió'),(2,'comodat'),(3,'compra'),(4,'dació'),(5,'desconeguda'),(6,'dipòsit'),(7,'donació'),(8,'entrega obligatòria'),(9,'excavació'),(10,'expropiació'),(11,'herència'),(12,'intercanvi'),(13,'llegat'),(14,'ocupació'),(15,'ofrena'),(16,'permuta'),(17,'premi'),(18,'propietat directa'),(19,'recol·lecció'),(20,'recuperació'),(21,'successió interadministrativa');
/*!40000 ALTER TABLE `vocabulario_formas_ingreso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_material`
--

DROP TABLE IF EXISTS `vocabulario_material`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `material` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_material`
--

LOCK TABLES `vocabulario_material` WRITE;
/*!40000 ALTER TABLE `vocabulario_material` DISABLE KEYS */;
INSERT INTO `vocabulario_material` VALUES (1,'Madera'),(2,'Metal'),(3,'Piedra'),(4,'Cerámica'),(5,'Textil'),(6,'Vidrio'),(7,'Papel'),(8,'Plástico'),(9,'Compuesto'),(10,'Resina');
/*!40000 ALTER TABLE `vocabulario_material` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_tecnica`
--

DROP TABLE IF EXISTS `vocabulario_tecnica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_tecnica` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tecnica` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_tecnica`
--

LOCK TABLES `vocabulario_tecnica` WRITE;
/*!40000 ALTER TABLE `vocabulario_tecnica` DISABLE KEYS */;
INSERT INTO `vocabulario_tecnica` VALUES (1,'Óleo sobre lienzo'),(2,'Acuarela'),(3,'Escultura en mármol'),(4,'Fotografía'),(5,'Grabado'),(6,'Cerámica esmaltada'),(7,'Pintura acrílica'),(8,'Dibujo a lápiz'),(9,'Técnica mixta'),(10,'Collage');
/*!40000 ALTER TABLE `vocabulario_tecnica` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vocabulario_tipos_exposicion`
--

DROP TABLE IF EXISTS `vocabulario_tipos_exposicion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vocabulario_tipos_exposicion` (
  `id` int(11) NOT NULL,
  `tipo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vocabulario_tipos_exposicion`
--

LOCK TABLES `vocabulario_tipos_exposicion` WRITE;
/*!40000 ALTER TABLE `vocabulario_tipos_exposicion` DISABLE KEYS */;
INSERT INTO `vocabulario_tipos_exposicion` VALUES (1,'Aliena'),(2,'Pròpia');
/*!40000 ALTER TABLE `vocabulario_tipos_exposicion` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-12-03  8:55:02
